
package decorate;

public class Food extends NoticeBoard {
  public Food() {
     descriotion="[먹방]";
  }

  public int getKeyword() {
      return 0;
  }

}
