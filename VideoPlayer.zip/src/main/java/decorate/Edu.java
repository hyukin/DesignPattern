
package decorate;

public class Edu extends NoticeBoard {
  public Edu() {
      descriotion="[교육]";
  }
  
  public int getKeyword() {
      return 0;
  }
}
