
package decorate;

public class Review extends NoticeBoard {
  public Review() {
      descriotion="[리뷰]";
  }

   public int getKeyword() {
      return 0;
  }

}
