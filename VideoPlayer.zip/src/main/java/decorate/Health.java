
package decorate;

public class Health extends NoticeBoard {
  public Health() {
        descriotion="[운동]";
  }

  public int getKeyword() {
      return 0;
  }

}
