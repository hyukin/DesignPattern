
package decorate;

public class Game extends NoticeBoard {
  public Game() {
      descriotion="[게임]";

  }

    public int getKeyword() {
      return 0;
  }

}
