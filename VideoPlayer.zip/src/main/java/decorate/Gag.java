
package decorate;

public class Gag extends NoticeBoard {
  public Gag() {
      descriotion="[예능]";

  }

    public int getKeyword() {
      return 0;
  }

}
