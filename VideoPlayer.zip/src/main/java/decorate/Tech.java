
package decorate;

public class Tech extends NoticeBoard {
  public Tech() {
     descriotion="[기술]";
  }

   public int getKeyword() {
      return 0;
  }

}
