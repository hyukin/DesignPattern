
package decorate;

public class Music extends NoticeBoard {
  public Music() {
      descriotion="[음악]";
  }

  public int getKeyword() {
      return 0;
  }

}
