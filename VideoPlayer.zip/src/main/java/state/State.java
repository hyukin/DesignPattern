package state;

public interface State {   
  public void entervideo() ;
  public void recommendation() ;
  public void subscribe() ;
  public void exitvideo() ;

}
