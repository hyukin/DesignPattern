package stratagy;

public abstract class SetListener {
    PrintGui printgui;
    int index;
    
    public int getIndex(){
        return index;
    }
}

