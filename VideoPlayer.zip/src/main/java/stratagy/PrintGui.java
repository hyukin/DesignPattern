package stratagy;

import java.awt.Image;

public interface PrintGui {
    void print();
    void setElement(Object tmp);
    Image getElement();
}
