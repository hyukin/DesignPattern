package gui;
import javax.swing.*;

public class SearchHistoryView {
    
    JComboBox combox = new JComboBox();
    
    public void test(){

        combox.addItem("최근검색기록");
        combox.setBounds(300, 70, 150, 30); 
        
    }
}
